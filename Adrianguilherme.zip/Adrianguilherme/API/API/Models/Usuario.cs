namespace ListaDeTarefas.Models;

public class Usuario
{
    public required string Id { get; set; }
    public string? Nome { get; set; }
    public required string Cpf { get; set; }
    public string? Genero { get; set; }
    public string? Email { get; set; }

}